#include "bc.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

int main() {
    printf("WRITE TESTS DUNKASS\n");
    exit(0);
}