// A handy extra function we can call.
int extra_fuction() {
    return 27;
}